export const logos = {
    'CWmrc1SLfd5bFOocvCoS' : {
        uri: require('./CWmrc1SLfd5bFOocvCoS.png'),
        ratio: 1 / 1
    },
    '7Ja8b6zdCqjhCJbyc1MR' : {
        uri: require('./7Ja8b6zdCqjhCJbyc1MR.png'),
        ratio: 1 / 1
    },
    'AyBu3PS42sinB5tk9VQl' : {
        uri: require('./AyBu3PS42sinB5tk9VQl.png'),
        ratio: 80 / 91
    },
    'B4z0XqHVJGcMEevKAZ4I' : {
        uri: require('./B4z0XqHVJGcMEevKAZ4I.png'),
        ratio: 1 / 1
    },
    'Bf5hvJAWCkoHYlhHDZ45' : {
        uri: require('./Bf5hvJAWCkoHYlhHDZ45.png'),
        ratio: 1 / 1
    },
    'KbzF302dMjscdGWAlYZt' : {
        uri: require('./KbzF302dMjscdGWAlYZt.png'),
        ratio: 20 / 21
    },
    'LnqOogNrmxCE9E2j3pR9' : {
        uri: require('./LnqOogNrmxCE9E2j3pR9.png'),
        ratio: 400 / 389
    },
    'PYQTKgsnjoxfa0zfVvOG' : {
        uri: require('./PYQTKgsnjoxfa0zfVvOG.png'),
        ratio: 263 / 335
    },
    'PfLiwJ1N3yKnxD2zqWpV' : {
        uri: require('./PfLiwJ1N3yKnxD2zqWpV.png'),
        ratio: 773 / 400
    },
    'aCEuObO9WWPfBhv1rAcK' : {
        uri: require('./aCEuObO9WWPfBhv1rAcK.png'),
        ratio: 400 / 409
    },
    'ebASDlRooDIGs50nDxmE' : {
        uri: require('./ebASDlRooDIGs50nDxmE.png'),
        ratio: 1 / 1
    },
    'hWi5ulMdiTtp1YKPHkW3' : {
        uri: require('./hWi5ulMdiTtp1YKPHkW3.png'),
        ratio: 361 / 498
    },
    'hXv2yyil3QxArqL8NZWS' : {
        uri: require('./hXv2yyil3QxArqL8NZWS.png'),
        ratio: 200 / 173
    },
    'xfT1eRVuICYEhEmbHszB' : {
        uri: require('./xfT1eRVuICYEhEmbHszB.png'),
        ratio: 1 / 1
    }
};