export const textlogos = {
    'CWmrc1SLfd5bFOocvCoS' : {
        uri: require('./CWmrc1SLfd5bFOocvCoS-Text.png'),
        ratio: 760 / 119
    },
    '7Ja8b6zdCqjhCJbyc1MR' : {
        uri: require('./7Ja8b6zdCqjhCJbyc1MR-Text.png'),
        ratio: 88 / 21
    },
    'AyBu3PS42sinB5tk9VQl' : {
        uri: require('./AyBu3PS42sinB5tk9VQl-Text.png'),
        ratio: 40 / 13
    },
    'B4z0XqHVJGcMEevKAZ4I' : {
        uri: require('./B4z0XqHVJGcMEevKAZ4I-Text.png'),
        ratio: 60 / 17
    },
    'Bf5hvJAWCkoHYlhHDZ45' : {
        uri: require('./Bf5hvJAWCkoHYlhHDZ45-Text.png'),
        ratio: 144 / 47
    },
    'KbzF302dMjscdGWAlYZt' : {
        uri: require('./KbzF302dMjscdGWAlYZt-Text.png'),
        ratio: 700 / 233
    },
    'LnqOogNrmxCE9E2j3pR9' : {
        uri: require('./LnqOogNrmxCE9E2j3pR9-Text.png'),
        ratio: 256 / 67
    },
    'PYQTKgsnjoxfa0zfVvOG' : {
        uri: require('./PYQTKgsnjoxfa0zfVvOG-Text.png'),
        ratio: 3837 / 1111
    },
    'PfLiwJ1N3yKnxD2zqWpV' : {
        uri: require('./PfLiwJ1N3yKnxD2zqWpV-Text.png'),
        ratio: 721 / 173
    },
    'aCEuObO9WWPfBhv1rAcK' : {
        uri: require('./aCEuObO9WWPfBhv1rAcK-Text.png'),
        ratio: 1023 / 824
    },
    'ebASDlRooDIGs50nDxmE' : {
        uri: require('./ebASDlRooDIGs50nDxmE-Text.png'),
        ratio: 820 / 237
    },
    'hWi5ulMdiTtp1YKPHkW3' : {
        uri: require('./hWi5ulMdiTtp1YKPHkW3-Text.png'),
        ratio: 501 / 250
    },
    'hXv2yyil3QxArqL8NZWS' : {
        uri: require('./hXv2yyil3QxArqL8NZWS-Text.png'),
        ratio: 47 / 7
    },
    'xfT1eRVuICYEhEmbHszB' : {
        uri: require('./xfT1eRVuICYEhEmbHszB-Text.png'),
        ratio: 4345 / 1351
    }
};